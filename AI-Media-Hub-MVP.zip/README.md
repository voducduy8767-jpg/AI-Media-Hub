# AI Media Hub MVP

Ứng dụng điều khiển Android (Expo) cho hệ thống sản xuất nội dung đa kênh.

## Chạy thử
1. Tải và giải nén thư mục này.
2. Mở thư mục bằng GitHub Codespaces hoặc môi trường có Node.js.
3. Chạy `npm install`
4. Chạy `npx expo start`
5. Mở Expo Go trên Android và quét QR (hoặc dùng link hiển thị trong terminal).

## Hiện có
- Dashboard tổng quan
- Tab quản lý kênh
- Tab xưởng sản xuất
- Tab cài đặt và nguyên tắc bảo mật

## Chưa có
- Backend/database
- Kết nối mô hình AI
- Tạo giọng đọc/audio
- Dựng video
- OAuth và đăng YouTube/TikTok/Facebook

Các tích hợp này sẽ được thêm từng bước. Không đặt API key trong ứng dụng di động.
