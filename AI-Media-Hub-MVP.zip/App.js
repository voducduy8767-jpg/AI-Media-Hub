import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, Pressable, StyleSheet, StatusBar } from 'react-native';

const colors = { bg:'#0B1020', panel:'#151D32', panel2:'#1B2741', text:'#F4F7FF', muted:'#9AA8C7', accent:'#7C9CFF', green:'#45D6A0', line:'#293653' };

function Stat({label, value, note}) {
  return <View style={s.stat}><Text style={s.muted}>{label}</Text><Text style={s.statValue}>{value}</Text><Text style={s.note}>{note}</Text></View>;
}
function Action({title, subtitle, onPress}) {
  return <Pressable onPress={onPress} style={s.action}><View style={{flex:1}}><Text style={s.actionTitle}>{title}</Text><Text style={s.muted}>{subtitle}</Text></View><Text style={s.arrow}>›</Text></Pressable>;
}
export default function App() {
  const [tab, setTab] = useState('Tổng quan');
  const [message, setMessage] = useState('Bản MVP đã sẵn sàng. Kết nối AI và YouTube sẽ được bổ sung ở bước tiếp theo.');
  const tabs = ['Tổng quan','Kênh','Sản xuất','Cài đặt'];
  return <SafeAreaView style={s.safe}>
    <StatusBar barStyle="light-content" />
    <View style={s.header}>
      <View><Text style={s.eyebrow}>BẢNG ĐIỀU KHIỂN</Text><Text style={s.logo}>AI Media Hub</Text></View>
      <View style={s.status}><View style={s.dot}/><Text style={s.statusText}>MVP</Text></View>
    </View>
    <ScrollView contentContainerStyle={s.content}>
      {tab === 'Tổng quan' && <>
        <Text style={s.heading}>Trung tâm vận hành</Text>
        <Text style={s.subheading}>Quản lý hệ thống nội dung YouTube, TikTok và Facebook.</Text>
        <View style={s.stats}><Stat label="Kênh đang quản lý" value="0" note="Chưa kết nối"/><Stat label="Video đã tạo" value="0" note="Chưa sản xuất"/></View>
        <View style={s.card}>
          <Text style={s.cardTitle}>Quy trình AI</Text>
          {['Nghiên cứu chủ đề','Viết kịch bản','Tạo giọng đọc & audio','Dựng video','Kiểm tra và đăng tải'].map((x,i)=><View style={s.step} key={x}><View style={s.stepNum}><Text style={s.stepNumText}>{i+1}</Text></View><Text style={s.stepText}>{x}</Text><Text style={s.pending}>Chờ</Text></View>)}
        </View>
        <Text style={s.cardTitle}>Thao tác nhanh</Text>
        <Action title="Tạo kế hoạch nội dung" subtitle="Chọn ngách và lên lịch video" onPress={()=>setMessage('Bước tiếp theo: xây module nghiên cứu ngách và lập kế hoạch 30 ngày.')}/>
        <Action title="Kết nối kênh YouTube" subtitle="Chuẩn bị kết nối qua Google OAuth" onPress={()=>setMessage('Chưa kết nối tài khoản. Ta sẽ cấu hình OAuth an toàn sau khi dựng backend.')}/>
        <Action title="Thiết lập sản xuất audio" subtitle="Giọng đọc, nhạc nền và hiệu ứng" onPress={()=>setMessage('Audio sẽ được tạo bằng AI; nhạc nền chỉ dùng nguồn có quyền sử dụng thương mại.')}/>
      </>}
      {tab === 'Kênh' && <><Text style={s.heading}>Kênh nội dung</Text><Text style={s.subheading}>Chưa có kênh nào được kết nối.</Text><Action title="YouTube" subtitle="Chưa kết nối" onPress={()=>setMessage('YouTube sẽ dùng Google OAuth; không nhập mật khẩu vào ứng dụng.')}/><Action title="TikTok" subtitle="Chưa kết nối" onPress={()=>setMessage('Tích hợp TikTok sẽ triển khai sau, theo quyền API được cấp.')}/><Action title="Facebook" subtitle="Chưa kết nối" onPress={()=>setMessage('Tích hợp Facebook sẽ triển khai sau.')}/></>}
      {tab === 'Sản xuất' && <><Text style={s.heading}>Xưởng sản xuất</Text><Text style={s.subheading}>Tự động hóa từng bước, có kiểm tra trước khi đăng.</Text><Action title="Kịch bản" subtitle="AI viết nội dung theo chủ đề" onPress={()=>setMessage('Module viết kịch bản chưa kết nối mô hình AI.')}/><Action title="Audio" subtitle="Tạo voice-over, nhạc và hiệu ứng" onPress={()=>setMessage('Module audio sẽ hỗ trợ TTS, mix giọng và nhạc có bản quyền phù hợp.')}/><Action title="Video" subtitle="Ghép hình, audio và phụ đề" onPress={()=>setMessage('Module dựng video sẽ được nối sau khi chọn công cụ tạo hình/video.')}/></>}
      {tab === 'Cài đặt' && <><Text style={s.heading}>Cài đặt hệ thống</Text><Text style={s.subheading}>Bản thử nghiệm chưa lưu khóa API hay dữ liệu tài khoản.</Text><View style={s.card}><Text style={s.cardTitle}>Nguyên tắc bảo mật</Text><Text style={s.body}>• Không gửi mật khẩu Google/YouTube cho AI.{'\n'}• API key sẽ lưu ở backend, không nhúng trong ứng dụng.{'\n'}• Video cần được kiểm tra bản quyền và chất lượng trước khi đăng.</Text></View></>}
      <View style={s.notice}><Text style={s.noticeTitle}>Thông báo</Text><Text style={s.noticeText}>{message}</Text></View>
    </ScrollView>
    <View style={s.nav}>{tabs.map(t=><Pressable key={t} onPress={()=>setTab(t)} style={s.navItem}><Text style={[s.navText,tab===t&&s.navActive]}>{t}</Text></Pressable>)}</View>
  </SafeAreaView>;
}
const s = StyleSheet.create({
 safe:{flex:1,backgroundColor:colors.bg}, header:{paddingHorizontal:20,paddingTop:14,paddingBottom:16,flexDirection:'row',justifyContent:'space-between',alignItems:'center',borderBottomWidth:1,borderColor:colors.line},
 eyebrow:{fontSize:10,letterSpacing:2,color:colors.muted,fontWeight:'700'}, logo:{fontSize:23,fontWeight:'800',color:colors.text,marginTop:4},
 status:{backgroundColor:'#18372F',paddingHorizontal:11,paddingVertical:7,borderRadius:20,flexDirection:'row',alignItems:'center',gap:6},dot:{width:7,height:7,borderRadius:5,backgroundColor:colors.green},statusText:{color:colors.green,fontWeight:'700',fontSize:11},
 content:{padding:18,paddingBottom:28},heading:{fontSize:25,fontWeight:'800',color:colors.text},subheading:{color:colors.muted,fontSize:13,lineHeight:20,marginTop:6,marginBottom:18},
 stats:{flexDirection:'row',gap:10,marginBottom:18},stat:{flex:1,backgroundColor:colors.panel,padding:15,borderRadius:15,borderWidth:1,borderColor:colors.line},muted:{color:colors.muted,fontSize:12},statValue:{fontSize:27,color:colors.text,fontWeight:'800',marginTop:8},note:{color:colors.muted,fontSize:10,marginTop:3},
 card:{backgroundColor:colors.panel,padding:16,borderRadius:16,borderWidth:1,borderColor:colors.line,marginBottom:20},cardTitle:{fontSize:16,fontWeight:'800',color:colors.text,marginBottom:12},step:{flexDirection:'row',alignItems:'center',paddingVertical:9,borderBottomWidth:1,borderColor:colors.line,gap:10},stepNum:{width:24,height:24,borderRadius:12,backgroundColor:colors.panel2,alignItems:'center',justifyContent:'center'},stepNumText:{color:colors.accent,fontWeight:'800',fontSize:11},stepText:{color:colors.text,flex:1,fontSize:13},pending:{color:'#E7BD72',fontSize:11},
 action:{backgroundColor:colors.panel,padding:15,borderRadius:14,borderWidth:1,borderColor:colors.line,marginBottom:9,flexDirection:'row',alignItems:'center'},actionTitle:{color:colors.text,fontSize:14,fontWeight:'700',marginBottom:4},arrow:{fontSize:26,color:colors.accent,marginLeft:10},
 notice:{backgroundColor:'#172440',borderRadius:13,padding:14,marginTop:12,borderWidth:1,borderColor:'#30466F'},noticeTitle:{color:colors.accent,fontWeight:'800',fontSize:12,marginBottom:5},noticeText:{color:colors.text,fontSize:12,lineHeight:18},
 body:{color:colors.muted,fontSize:13,lineHeight:23},nav:{flexDirection:'row',borderTopWidth:1,borderColor:colors.line,paddingVertical:12,paddingHorizontal:4,backgroundColor:colors.panel},navItem:{flex:1,alignItems:'center'},navText:{fontSize:11,color:colors.muted},navActive:{color:colors.accent,fontWeight:'800'}
});
